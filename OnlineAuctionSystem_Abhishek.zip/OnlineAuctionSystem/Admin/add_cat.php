<?php

require_once('../config.php');
require_once('header.php');

?>

<div class="content-wrapper p-5">
     <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add a Product Category</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="insert_cat.php" method="POST" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label>Category</label>
                    <input type="text" class="form-control" placeholder="Enter Category Name" name="category">
                  </div>
                  <div class="form-group">
                    <label>Select an image for the category</label>
                    <input type="file" class="form-control" name="cat_image">
                  </div>
                  
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Add</button>
                </div>
              </form>
            </div>

</div>


<?php

require_once('footer.php');


?>