<?php

require_once('../config.php');
$username = $_POST['username'];
$password = $_POST['password'];
$insert = "INSERT INTO admin (username,password) VALUES ('$username','$password')";
mysqli_query($conn,$insert);
header("Location:admin_login.php");

?>