<?php


require_once('../config.php');
$username = $_POST['username'];
$password = $_POST['password'];
$select = "SELECT * FROM online_auction_admin WHERE username='$username' && password='$password'";
$query = mysqli_query($conn,$select);
$res = mysqli_fetch_assoc($query);
if(mysqli_num_rows($query) > 0){
    session_start();
    $_SESSION['user_name'] = $res['username'];
    header("Location:index.php");
} else {
    session_destroy();
    header("Location:admin_login.php?err=1");
}

?>