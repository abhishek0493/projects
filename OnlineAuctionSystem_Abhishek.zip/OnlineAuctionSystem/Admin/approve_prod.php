<?php

require_once('../config.php');
$id = $_GET['id'];
$status = '1';
echo $update = "UPDATE online_auction_product SET status='$status' WHERE prod_id='$id'";
mysqli_query($conn,$update);
header("Location:view_prod.php");


?>