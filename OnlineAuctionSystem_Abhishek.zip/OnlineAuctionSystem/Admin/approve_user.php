<?php


require_once('../config.php');
$id = $_GET['id'];
$status = '1';
$update = "UPDATE online_auction_users SET status='$status' WHERE user_id='$id'";
mysqli_query($conn,$update);
header("Location:view_user.php");


?>