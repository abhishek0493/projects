<?php

require_once('../config.php');
$id = $_GET['id'];
$delete = "DELETE FROM online_auction_category WHERE cat_id='$id'";
mysqli_query($conn,$delete);
header("Location:view_cat.php");

?>