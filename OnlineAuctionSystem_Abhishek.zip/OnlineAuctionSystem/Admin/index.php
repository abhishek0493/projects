<?php

require_once('../config.php');
require_once("header.php");

// USer QUery
$user_select = "SELECT * FROM online_auction_users";
$query_user = mysqli_query($conn, $user_select);
$user_select2 = "SELECT * FROM online_auction_users WHERE status='1'";
$query2_user = mysqli_query($conn, $user_select2);

// Product Query
$select_prod = "SELECT * FROM online_auction_product";
$query_prod = mysqli_query($conn, $select_prod);
$select_prod2 = "SELECT * FROM online_auction_product WHERE status='1'";
$query_prod2 = mysqli_query($conn, $select_prod2);

// Bids Query
$select_bids = "SELECT * FROM online_auction_bids";
$query_bids = mysqli_query($conn, $select_prod);
$select_bids2 = "SELECT * FROM online_auction_bids WHERE status='1'";
$query_bids2 = mysqli_query($conn, $select_prod2);

// categories 
$select_cat = "SELECT * FROM online_auction_category";
$query_cat = mysqli_query($conn, $select_cat);

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Admin Home</title>
</head>

<body>

  <div class="container-fluid">

    <div class="row">


      <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Categories</div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo mysqli_num_rows($query_cat); ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-calendar fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>


      <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Approved / Total Users</div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo mysqli_num_rows($query2_user); ?> / <?php echo mysqli_num_rows($query_user);   ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-calendar fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Approved / Total Products</div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo mysqli_num_rows($query_prod2); ?> / <?php echo mysqli_num_rows($query_prod);     ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-calendar fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Finished / Total Bids</div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo mysqli_num_rows($query_bids2); ?> / <?php echo mysqli_num_rows($query_bids);     ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-calendar fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>


    </div>
  </div>

</body>

</html>




<?php

require_once('footer.php');


?>