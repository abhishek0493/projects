<?php

require_once('../config.php');
$cat = $_POST['category'];
$image = $_FILES['cat_image']['name'];
// print_r($image);
$img_array = explode(".",$image);
// print_r($img_array);
// die;
$ext = $img_array[count($img_array)-1];
$new_image_file = Date("Ymdhis");
$new_cat_img = $new_image_file.".".$ext;
$source = $_FILES['cat_image']['tmp_name'];
$destination = "uploads/".$new_cat_img;
move_uploaded_file($source,$destination);
$insert = "INSERT INTO online_auction_category (cat_name,cat_image) VALUES ('$cat','$new_cat_img')";
mysqli_query($conn,$insert);
header("Location:index.php");

?>
