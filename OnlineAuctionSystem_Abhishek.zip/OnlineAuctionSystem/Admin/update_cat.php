<?php

require_once("../config.php");

$id = $_POST['cat_id'];
$cat_name = $_POST['category'];
$old_image = $_POST['old_img'];
$file_name = $_FILES['cat_image']['name'];

if($file_name == ""){
    $new_image = $old_image;
} else {
    unlink("uploads/".$old_image);
    $img_array = explode(".",$file_name);
    $ext = $img_array[count($img_array) - 1];
    $new_file = Date("Ymdhis");
    $new_image = $new_file.".".$ext;
    $source = $_FILES['cat_image']['tmp_name'];
    $destination = "uploads/".$new_image;
    move_uploaded_file($source,$destination);
};

$update = "UPDATE online_auction_category SET cat_name='$cat_name', cat_image='$new_image' WHERE cat_id='$id'";
mysqli_query($conn,$update);
header("Location:view_cat.php");


?>