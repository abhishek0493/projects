<?php

require_once('../config.php');
require_once('header.php');
$select = "SELECT online_auction_bids.*,online_auction_product.name as prod_name FROM online_auction_bids
JOIN online_auction_product ON online_auction_bids.prod_id=online_auction_product.prod_id";
$query = mysqli_query($conn,$select);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Bids</title>
</head>
<body>
    


 <div class="container-fluid">

         
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead class="bg-gradient-secondary text-white">
                    <tr>
                      <th>Bid ID</th>
                      <th>Product ID</th> 
                      <th>Product</th> 
                      <th>User ID</th>
                      <th>Email</th>
                      <th>Bid Amount</th> 
                      <th>Status</th> 
                    </tr>
                  </thead>
                  <tfoot class="bg-gradient-secondary text-white">
                    <tr>
                     <th>Bid ID</th>
                      <th>Product ID</th> 
                      <th>Product</th> 
                      <th>User ID</th>
                      <th>Email</th>
                      <th>Bid Amount</th> 
                      <th>Status</th> 
                    </tr>
                  </tfoot>
                  <tbody>
                      <?php
                      while($res = mysqli_fetch_assoc($query)){
                        $userID = $res['user_id'];
                        $select2 = "SELECT * FROM online_auction_users WHERE user_id='$userID'";
                        $query2 = mysqli_query($conn,$select2);
                        $res2 = mysqli_fetch_assoc($query2);

                      ?>
                    <tr>
                        <td><?php echo $res['bid_id'];   ?></td>
                        <td><?php echo $res['prod_id']   ?></td>
                        <td><?php echo $res['prod_name'];   ?></td>
                        <td><?php echo $res['user_id'];   ?></td>
                        <td><?php echo $res2['email'];   ?></td>
                        <td><?php echo $res['bid_amount'];   ?></td>
                        <td class="font-weight-bold"><?php echo $res['bid_status'];   ?></td>
                    </tr>

                      <?php  } 
                      ?>
          </tbody>
          </table>
          </div>
          </div>
          </div>
          </div>

         
          
        

          <?php  require_once('footer.php');  ?>

          </body>
</html>