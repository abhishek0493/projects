<?php

require_once('../config.php');
require_once('header.php');
$select = "SELECT * FROM online_auction_category";
$query = mysqli_query($conn,$select);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Categories</title>
</head>
<body>
  


 <div class="container-fluid">

         
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h2>Categories</h2>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead class="bg-gradient-secondary text-white">
                    <tr>
                      <th>Category ID</th>
                      <th>Category</th>
                      <th>Image</th> 
                      <th>Action</th> 
                    </tr>
                  </thead>
                  <tfoot class="bg-gradient-secondary text-white">
                    <tr>
                      <th>Category ID</th>
                      <th>Category</th>
                      <th>Image</th>
                      <th>Action</th> 
                    </tr>
                  </tfoot>
                  <tbody>
                      <?php
                      $i = 1;
                      while($res = mysqli_fetch_assoc($query)){
                      ?>
                    <tr>
                        <td><?php  echo $res['cat_id']; ?></td>
                        <td><?php  echo $res['cat_name']; ?></td>
                        <td><img src="uploads/<?php echo $res['cat_image']; ?>" alt="" height="150" width="150"></td>
                        <td>
                          <a href="delete_cat.php?id=<?php echo $res['cat_id'];  ?>">Delete</a>
                          <a href="" onclick="edit_cat(<?php echo $res['cat_id']; ?>)" data-toggle="modal" data-target="#edit_cat" class="d-block my-2">Edit</a>
                        </td>
                    </tr>

                      <?php  }  ?>
          </tbody>
          </table>
          </div>
          </div>
          </div>
          </div>

        

          
        

          <?php  require_once('footer.php');  
          
                       ?>


                         <div class="modal fade" id="edit_cat">
                <div class="modal-dialog modal-dialog-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <p>Edit Category</p>
                            </div>
                            <div class="modal-body">
                                 <form action="update_cat.php" method="POST" enctype="multipart/form-data">
                                    <div class="card-body">
                                      <div class="form-group">
                                        <label>Category</label>
                                        <input type="text" class="form-control" placeholder="Enter Category Name" name="category">
                                      </div>
                                      <div class="form-group">
                                        <label>Select an image for the category</label>
                                        <input type="file" class="form-control" name="cat_image">
                                        <input type="hidden" name="old_img">
                                        <input type="hidden" name="cat_id">
                                      </div>
                  
                <!-- /.card-body -->

                                    <div class="card-footer">
                                      <button type="submit" class="btn btn-primary">Add</button>
                                    </div>
                                  </form>
                            </div>
                        </div>
                </div>
          </div>


                       <script>

                           function edit_cat(id){
                             $.ajax({
                               url:'get_single_cat.php',
                               data:'id='+id,
                               type:'post',
                               dataType:'json',
                               success:function(data){
                                 $('input[name="category"]').val(data.cat_name);
                                 $('input[name="old_img"]').val(data.cat_image);
                                 $('input[name="cat_id"]').val(data.cat_id);
                               }
                             })
                           }
                       
                       </script>

          </body>
</html>