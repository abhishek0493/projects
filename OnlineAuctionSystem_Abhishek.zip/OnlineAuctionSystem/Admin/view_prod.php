<?php

require_once('../config.php');
require_once('header.php');
$select = "SELECT online_auction_product.*,
online_auction_users.name as userName,
online_auction_users.email as user_email
FROM online_auction_product 
JOIN online_auction_users 
ON online_auction_product.u_id=online_auction_users.user_id 
ORDER BY prod_id DESC";
$query = mysqli_query($conn, $select);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Products</title>
</head>

<body>



    <div class="container-fluid">

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Products</h6>
            </div>


            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead class="bg-gradient-secondary">
                            <tr>
                                <th class="text-white">Prod ID</th>
                                <th class="text-white">Added By</th>
                                <th class="text-white">User ID</th>
                                <th class="text-white">Cat ID</th>
                                <th class="text-white">Name</th>
                                <th class="text-white">Description</th>
                                <th class="text-white">Image</th>
                                <th class="text-white">Starting bid</th>
                                <th class="text-white">Start Date</th>
                                <th class="text-white">Due Date</th>
                                <th class="text-white">status</th>
                                <th class="text-white">Action</th>
                            </tr>
                        </thead>
                        <tfoot class="bg-gradient-secondary">
                            <tr>
                                <th class="text-white">User ID</th>
                                <th class="text-white">Prod ID</th>
                                <th class="text-white">Added By</th>
                                <th class="text-white">Cat ID</th>
                                <th class="text-white">Name</th>
                                <th class="text-white">Description</th>
                                <th class="text-white">Image</th>
                                <th class="text-white">Starting bid</th>
                                <th class="text-white">Start Date</th>
                                <th class="text-white">Due Date</th>
                                <th class="text-white">status</th>
                                <th class="text-white">Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php
                            while ($res = mysqli_fetch_assoc($query)) {
                                ?>
                            <tr>
                                <td><?php echo $res['prod_id'];   ?></td>
                                <td><?php echo $res['user_email'];   ?></td>
                                <td><?php echo $res['u_id'];   ?></td>
                                <td><?php echo $res['cat_id']   ?></td>
                                <td><?php echo $res['name'];   ?></td>
                                <td><?php echo $res['description'];   ?></td>
                                <td><img src="../uploads/<?php echo $res['p_image']; ?>" height="150" width="150"></td>
                                <td><?php echo $res['starting_bid'];   ?></td>
                                <td><?php echo $res['start_date'];   ?></td>
                                <td><?php echo $res['due_date'];   ?></td>
                                <td class="font-weight-bold"><?php echo $res['status'];   ?></td>
                                <td>
                                    <a href="approve_prod.php?id=<?php echo $res['prod_id']; ?>"
                                        class="btn btn-primary <?php if ($res['status'] == 1) {
                                                                                                                                    echo "disabled";
                                                                                                                                }  ?>">
                                        Approve</a>
                                    <a href="delete_prod.php?id=<?php echo $res['prod_id']; ?>"
                                        class="btn btn-primary my-2">Delete</a>

                                </td>

                            </tr>

                            <?php  }  ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>





    <?php require_once('footer.php');  ?>


</body>

</html>