<?php

require_once('../config.php');
require_once('header.php');
$select = "SELECT * FROM online_auction_users";
$query = mysqli_query($conn, $select);

$select2 = "SELECT * FROM online_auction_users WHERE status='0'";
$query2 = mysqli_query($conn, $select2);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Users</title>
</head>

<body>



    <div class="container-fluid">


        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Users</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead class="bg-gradient-secondary">
                            <tr>
                                <th class="text-white">User ID</th>
                                <th class="text-white">Name</th>
                                <th class="text-white">Email</th>
                                <th class="text-white">Password</th>
                                <th class="text-white">contact</th>
                                <th class="text-white">Status</th>
                                <th class="text-white">Action</th>
                            </tr>
                        </thead>
                        <tfoot class="bg-gradient-secondary">
                            <tr>
                                <th class="text-white">User ID</th>
                                <th class="text-white">Name</th>
                                <th class="text-white">Email</th>
                                <th class="text-white">Password</th>
                                <th class="text-white">contact</th>
                                <th class="text-white">Status</th>
                                <th class="text-white">Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php
              $i = 1;
              while ($res = mysqli_fetch_assoc($query)) {
                ?>
                            <tr>
                                <td><?php echo $res['user_id'];   ?></td>
                                <td><?php echo $res['name'];   ?></td>
                                <td><?php echo $res['email'];   ?></td>
                                <td><?php echo $res['password'];   ?></td>
                                <td><?php echo $res['contact'];   ?></td>
                                <td class="font-weight-bold"><?php echo $res['status'];  ?></td>
                                <td>
                                    <a href="approve_user.php?id=<?php echo $res['user_id']; ?>" class="btn btn-primary <?php if ($res['status'] == 1) {
                                                                                                            echo "disabled";
                                                                                                          } ?>">
                                        Approve</a>
                                </td>
                            </tr>

                            <?php  }  ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php require_once('footer.php');

  ?>

    <script>


    </script>

</body>

</html>