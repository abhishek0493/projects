-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2019 at 04:58 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.2.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlineauctionsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `online_auction_admin`
--

CREATE TABLE `online_auction_admin` (
  `username` varchar(100) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `online_auction_admin`
--

INSERT INTO `online_auction_admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `online_auction_bidlog`
--

CREATE TABLE `online_auction_bidlog` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `online_auction_bidlog`
--

INSERT INTO `online_auction_bidlog` (`id`, `user_id`, `prod_id`, `amount`) VALUES
(1, 1, 1, 60000),
(2, 1, 2, 60000),
(3, 2, 6, 22000),
(4, 2, 4, 88000),
(5, 2, 3, 66000),
(6, 3, 1, 30000),
(7, 3, 2, 59000),
(8, 1, 8, 50000),
(9, 1, 7, 28000),
(10, 6, 9, 58000),
(11, 6, 1, 34000);

-- --------------------------------------------------------

--
-- Table structure for table `online_auction_bids`
--

CREATE TABLE `online_auction_bids` (
  `bid_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `bid_amount` int(11) NOT NULL,
  `bid_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `online_auction_bids`
--

INSERT INTO `online_auction_bids` (`bid_id`, `user_id`, `prod_id`, `bid_amount`, `bid_status`) VALUES
(1, 6, 1, 34000, 1),
(2, 1, 2, 60000, 1),
(3, 2, 6, 22000, 0),
(4, 2, 4, 88000, 0),
(5, 2, 3, 66000, 0),
(6, 1, 8, 50000, 0),
(7, 1, 7, 28000, 1),
(8, 6, 9, 58000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `online_auction_category`
--

CREATE TABLE `online_auction_category` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(100) NOT NULL,
  `cat_image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `online_auction_category`
--

INSERT INTO `online_auction_category` (`cat_id`, `cat_name`, `cat_image`) VALUES
(1, 'Laptops', '20191029011827.jpg'),
(2, 'Smartphones', '20191014113040.jpg'),
(3, 'Televisions', '20191029012031.jpg'),
(5, 'Gaming Consoles', '20191014115944.jpg'),
(6, 'Home Audio & Theatre', '20191014120321.jpg'),
(7, 'DSLR Cameras', '20191026104529.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `online_auction_product`
--

CREATE TABLE `online_auction_product` (
  `prod_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `p_image` varchar(100) NOT NULL,
  `starting_bid` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `due_date` date NOT NULL,
  `u_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `online_auction_product`
--

INSERT INTO `online_auction_product` (`prod_id`, `cat_id`, `name`, `description`, `p_image`, `starting_bid`, `start_date`, `due_date`, `u_id`, `status`) VALUES
(1, 2, 'One Plus 7t ', 'New OnePlus 7t now with 90 hz refresh rate . ', '20191104044855.jpg', 25000, '2019-11-04', '2019-11-06', 2, 1),
(2, 2, 'Samsung Galaxy Note 10', 'Experience the new Note 10 now with bigger and better display and even better performance.', '20191104045131.jpg', 55000, '2019-11-04', '2019-11-06', 2, 1),
(3, 2, 'iPhone 11 Pro', 'The new iPhone', '20191104045330.jpg', 65000, '2019-11-04', '2019-11-07', 1, 1),
(4, 1, 'Acer Predator Helios 300', 'The Beast in Laptop Gaming.', '20191104045602.jpg', 85000, '2019-11-04', '2019-11-08', 1, 1),
(5, 1, 'MacBook Pro', 'New MacBook Pro', '20191104045926.jpg', 95000, '2019-11-04', '2019-11-07', 1, 0),
(6, 1, 'Sony PS4 Pro', 'Playstation 4 Pro with 4k Gaming', '20191104050249.jpg', 20000, '2019-11-04', '2019-11-07', 1, 1),
(7, 3, 'Product 1', 'test random', '20191104050912.jpg', 25000, '2019-11-04', '2019-11-04', 3, 1),
(8, 6, 'Product 2', 'testing 2', '20191104051126.jpg', 48000, '2019-11-04', '2019-11-08', 3, 1),
(9, 7, 'Product 3', 'ksakdkasdkl', '20191104051514.jpg', 55000, '2019-11-04', '2019-11-07', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `online_auction_users`
--

CREATE TABLE `online_auction_users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `contact` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `online_auction_users`
--

INSERT INTO `online_auction_users` (`user_id`, `name`, `email`, `password`, `contact`, `status`) VALUES
(1, 'Abhishek', 'abhishek@gmail.com', 'abhi123', '9869467265', 1),
(2, 'rohan', 'rohan@gmail.com', 'rohan123', '8888555666', 1),
(3, 'mitansh', 'mitansh@gmail.com', 'mitansh123', '88884444112', 1),
(6, 'Rohan', 'rohan.vani@gmail.com', 'rohan', '12345678', 1),
(7, 'bhavna', 'bhavna11patidar@gmail.com', '12345', '1234567890', 1),
(8, 'sagar', 'sagar@gmail.com', 'sagar123', '9869811111', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `online_auction_bidlog`
--
ALTER TABLE `online_auction_bidlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `online_auction_bids`
--
ALTER TABLE `online_auction_bids`
  ADD PRIMARY KEY (`bid_id`);

--
-- Indexes for table `online_auction_category`
--
ALTER TABLE `online_auction_category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `online_auction_product`
--
ALTER TABLE `online_auction_product`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `online_auction_users`
--
ALTER TABLE `online_auction_users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `online_auction_bidlog`
--
ALTER TABLE `online_auction_bidlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `online_auction_bids`
--
ALTER TABLE `online_auction_bids`
  MODIFY `bid_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `online_auction_category`
--
ALTER TABLE `online_auction_category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `online_auction_product`
--
ALTER TABLE `online_auction_product`
  MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `online_auction_users`
--
ALTER TABLE `online_auction_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
