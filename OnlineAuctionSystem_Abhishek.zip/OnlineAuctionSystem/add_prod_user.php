<?php

require_once('config.php');
require_once('header.php');
$select = "SELECT * FROM online_auction_category";
$query = mysqli_query($conn, $select);
$current_date = date("Y-m-d H:i:s");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Product</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <?php

    if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != "") {

        ?>
    <section id="add_prod">
        <div class="container p-4">
            <h2 class="text-center" id="prod_header">Enter Product Details</h2>
            <?php
                    if (isset($_GET['error']) && $_GET['error'] == 2) {
                        echo "<h4 class='text-center text-danger'> ----- Invalid Date Selection -----</h4>";
                    } elseif (isset($_GET['error']) && $_GET['error'] == 1) {
                        echo "<h4 class='text-center text-danger'> ----- All Fields are mandatory -----</h4>";
                    }

                    ?>
            <form action="insert_prod_user.php" class="mt-5" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>Product <span> Name</span></label>
                            <input type="text" class="form-control mb-5" placeholder="Enter Product Name" name="pname">
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>Select a <span>Category</span> </label>
                            <select class="form-control mb-5" name="category">
                                <option>Select a Category</option>
                                <?php
                                        while ($res = mysqli_fetch_assoc($query)) {

                                            ?>
                                <option value="<?php echo $res['cat_id'];   ?>"><?php echo $res['cat_name'];   ?>
                                </option>
                                <?php  }  ?>
                            </select>
                        </div>
                    </div>
                </div>


                <div class="form-group">
                    <label>Enter Product <span>Description</span></label>
                    <textarea class="form-control mb-5" rows="3" name="descript"
                        placeholder="Describe your product in few words"></textarea>
                </div>

                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mx-auto">Select an <span>image</span> for the product </label>
                            <input type="file" class="form-control mb-5" name="image">
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mx-auto">Enter <span>starting bid</span> for the product </label>
                            <input type="number" class="form-control mb-5" name="start_bid">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="text-center d-block"><span>Starting</span> Date</label>
                    <input type="date" class="form-control mb-5 w-50 mx-auto" name="start_date">
                </div>

                <div class="form-group">
                    <label class="text-center d-block"> <span>Due</span> Date</label>
                    <input type="date" class="form-control mb-5 w-50 mx-auto" name="due_date">
                </div>

                <input type="submit" class="btn btn-lg mt-4 mx-auto d-block w-25" id="prod_submit" value="Submit">
                <input type="hidden" value="<?php echo $_SESSION['user_id']; ?>" name="user_id">

            </form>
        </div>

    </section>

    <?php  } else {

        ?>

    <div class="container p-5 mx-auto text-center mt-5">
        <h2 class="text-danger display-4">You need to Register to sell products or to start bidding</h2>
        <div class="container mt-5">
            <h4><a href="register_user.php" class="mt-5" style="font-size:30px">Click here</a> to Register</h4>
            <h4 class="mt-2 text-info">OR</h4>
            <h4> <a href="login_user.php">Login</a> if already registered </h4>
        </div>
    </div>



    <?php       }  ?>

    <?php require_once('footer.php');
    ?>



</body>

</html>