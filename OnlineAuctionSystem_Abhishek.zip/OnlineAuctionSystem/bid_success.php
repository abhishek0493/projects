<?php
require_once('config.php');
header("refresh:2;url=view_prod_final.php");
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Bid Success</title>
</head>

<body>
    <?php require_once('header.php');   ?>

    <div class="container mx-auto p-5">
        <?php

        if (isset($_GET['bid_error']) && $_GET['bid_error'] == 1) {
            echo "<h4 class='display-4 text-center text-danger'>Bid must be Higher than Base Price</h4>";
        } elseif (isset($_GET['bid_error']) && $_GET['bid_error'] == 2) {
            echo "<h4 class='display-4 text-center text-danger'>Bid must be Higher than previous Bid</h4>";
        } elseif (isset($_GET['bid_error']) && $_GET['bid_error'] == 3) {
            echo "<h4 class='display-4 text-center text-danger'>You cant bid on your product</h4>";
        } else {
            echo "<h4 class='display-4 text-center text-success'>Bid Placed Successfully</h4>";
        };
        ?>
        <p class="text-secondary text-center mt-5">Redirecting to products</p>
    </div>
    <?php require_once('footer.php');  ?>
</body>

</html>