<?php

require_once('config.php');
$email = $_POST['email'];
$password = $_POST['password'];
// $status = '1';
$select = "SELECT * FROM online_auction_users WHERE email='$email' && password='$password'";
$query = mysqli_query($conn, $select);
$res = mysqli_fetch_assoc($query);
if (mysqli_num_rows($query) > 0) {
    if ($res['status'] == 1) {
        session_start();
        $_SESSION['user_id'] = $res['user_id'];
        $_SESSION['user_name'] = $res['name'];
        header("Location:index.php");
    } else {
        session_destroy();
        header("Location:login_user.php?error_msg=2");
    }
} else {
    session_destroy();
    header("Location:login_user.php?error_msg=1");
}
