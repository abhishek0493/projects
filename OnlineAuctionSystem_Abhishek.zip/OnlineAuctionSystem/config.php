<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "onlineauctionsystem";
$conn = mysqli_connect($host, $username, $password, $database);