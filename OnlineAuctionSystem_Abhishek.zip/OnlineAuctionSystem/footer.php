<footer>
    <div class="container-fluid text-center p-4">
            <h5>My Website &copy; All Rights reserved</h5>
    </div>
</footer>