<?php

require_once('config.php');
$id = $_POST['id'];
$select = "SELECT * FROM online_auction_product WHERE prod_id='$id'";
$query = mysqli_query($conn,$select);
$res = mysqli_fetch_assoc($query);
echo json_encode($res);

?>