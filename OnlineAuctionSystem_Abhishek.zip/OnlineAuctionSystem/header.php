<?php
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="./CSS/bootstrap.min.css" />
    <link rel="stylesheet" href="./CSS/style.css?<?php echo time();  ?>" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="./fontawesome-free-5.11.2-web/css/all.css" />
</head>

<body>

</body>

</html>

<body onscroll="scrollFunction()">
    <nav class="navbar navbar-expand-lg sticky-top shadow-lg" id="main_nav">
        <a class="navbar-brand" href="index.php"><img src="./images/logo-default-658x114.png" alt="logo"
                id="logo_img" /></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#aboutUs">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="add_prod_user.php">Sell</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Buy
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <a class="dropdown-item" href="view_prod_final.php">View all Products</a>
                        <a class="dropdown-item" href="view_cat.php">View all Categories</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php
            if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != "") {
              echo  $_SESSION['user_name'];
            } else {
              echo "Profile";
            }
            ?>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <?php
            if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != "") {
              echo "<p class='dropdown-header'> Welcome</p>";
            } else {
              ?>
                        <a class="dropdown-item" href="login_user.php">Login</a>

                        <?php      }  ?>

                        <?php
            if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != "") {
              ?>
                        <a class="dropdown-item" href="view_user_bid_prod.php">View my bids</a>
                        <a class="dropdown-item" href="logout_user.php">Logout</a>
                        <?php  } else {
              echo "<p></p>";
            }   ?>
                        <?php
            if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != "") {

              ?>

                        <?php  } else {
              echo " <a class='dropdown-item' href='register_user.php'>Register</a>";
            }

            ?>
                    </div>
                </li>

            </ul>
        </div>
    </nav>


    <script>
    function scrollFunction() {
        var a = document.getElementById("main_nav");
        var b = document.getElementById("logo_img");
        var c = document.getElementsByClassName("nav-link");
        // var d = document.getElementsByClassName("navbar-nav");
        if (
            document.body.scrollTop > 0 ||
            document.documentElement.scrollTop > 0
        ) {
            a.style.padding = "18px";
            b.style.height = "5vh";
            for (var i = 0; i < c.length; i++) {
                c[i].style.fontSize = "22px";
            }
        } else {
            a.style.padding = "1.5rem";
            b.style.height = "8vh";
            for (var i = 0; i < c.length; i++) {
                c[i].style.fontSize = "1.5rem";
            }
        }
    }
    </script>





    <script src="./JS/popper.min.js"></script>
    <script src="./JS/jquery.min.js"></script>
    <script src="./JS/bootstrap.min.js"></script>

</body>