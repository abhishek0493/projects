<?php

require_once("config.php");
require_once('header.php');
$select  = "SELECT * FROM online_auction_category";
$query = mysqli_query($conn, $select);

$select2 = "SELECT online_auction_bids.*,online_auction_product.p_image as prod_image,
online_auction_product.name as prod_name FROM online_auction_bids JOIN online_auction_product 
ON online_auction_bids.prod_id=online_auction_product.prod_id WHERE bid_status='1' ORDER BY prod_id DESC LIMIT 7";
$query2 = mysqli_query($conn, $select2);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="./style.css">
</head>

<body>



    <!-- Home Section Begins -->

    <section id="home">
        <div class="row">
            <div class="col-lg-6">
                <img src="./images/2111458.jpg" alt="" id="home_img" />
            </div>
            <div class="col-lg-6">
                <h2 id="home_tag_line" class="mt-5">
                    The best place <span> to buy and sell! </span>
                </h2>
                <a href="register_user.php" class="btn btn-danger mt-5" id="register_btn">
                    Register
                </a>
            </div>
        </div>
    </section>

    <!-- Info Section -->
    <section id="info">
        <h1 class="mt-2 ml-5" id="info-head">How <span>It Works</span></h1>
        <div class="row mt-5 justify-content-center">
            <div class="col-lg-3">
                <i class="fas fa-camera"></i>
                <h4 class="mt-4 text-center">Register</h4>
                <p class="my-3 text-center">
                    To start using our auction, you’ll need to register. It’s completely
                    free and requires just a few clicks!
                </p>
            </div>

            <div class="col-lg-3">
                <i class="fas fa-shopping-cart"></i>
                <h4 class="mt-4 text-center">Sell or Bid</h4>
                <p class="my-3 text-center">
                    You can place a bid on any desired product right
                    after registration and approval from admin on our website.
                </p>
            </div>

            <div class="col-lg-3">
                <i class="fas fa-gavel"></i>
                <h4 class="mt-4 text-center">Submit a Bid</h4>
                <p class="my-3 text-center">
                    Submitting a bid to our auction is quick and easy. The process takes
                    just a few minutes.
                </p>
            </div>

            <div class="col-lg-3">
                <i class="fas fa-trophy"></i>
                <h4 class="mt-4 text-center">Win</h4>
                <p class="my-3 text-center">
                    Easily win at our auction and enjoy owning the product you dream of
                    after the bidding is closed.
                </p>
            </div>
        </div>
    </section>

    <!-- Category -->


    <section id="category">
        <h2 class="display-4 ml-5">Categories</h2>
        <div class="container-fluid shadow-lg my-5">
            <div class="row">
                <?php
        while ($res = mysqli_fetch_assoc($query)) {

          ?>
                <div class="col p-5">
                    <div class="card shadow-md">
                        <div class="card-body">
                            <img src="./Admin/uploads/<?php echo $res['cat_image'];   ?>" alt="" height="150"
                                width="150" class="mx-auto d-block" />
                        </div>
                        <div class="card-footer">
                            <a class="text-center stretched-link"
                                href="view_prod_by_cat2.php?id=<?php echo $res['cat_id'];  ?>">
                                <?php echo $res['cat_name'];  ?></a>
                        </div>
                    </div>
                </div>

                <?php  } ?>
            </div>
        </div>
    </section>

    <!-- Finished Auctions -->

    <?php

  if (mysqli_num_rows($query2) > 0) {
    ?>
    <section id="Finish">
        <div class="container-fluid text-center">
            <h1 id='fh2' class='display-4'>Finished <span>Auctions</span></h1>
            <div class="row mt-5">
                <?php
            while ($res = mysqli_fetch_assoc($query2)) {
              ?>
                <div class="col mx-5 my-5">
                    <img src="./uploads/<?php echo $res["prod_image"];   ?>" alt="" height="200" width="200">
                    <h3 class='my-3 prod_name'><?php echo $res["prod_name"];  ?></h3>
                    <h4 class='final_price'>Final Price <span class='d-block'> Rs <?php echo $res["bid_amount"];  ?>
                        </span></h4>
                </div>
                <?php  }  ?>
            </div>
        </div>
    </section>

    <?php  }  ?>

    <!-- About Us -->

    <section id="aboutUs" class="container-fluid jumbotron text-center">
        <h2 class="display-4" id="abt_header">About <span>Us</span> </h2>
        <h3 class="my-5">Quality Products for the customers</h3>
        <div class="icons mt-5">
            <i class="fas fa-laptop"></i>
            <i class="fas fa-shopping-cart"></i>
            <i class="fas fa-camera"></i>
            <i class="fas fa-gamepad"></i>
        </div>
        <div class="info">
            <h5 class="w-75 mx-auto mt-4">Online Auction features a wide variety of quality products at wholesale
                prices.
                We strive to make sure our customers are completely satisfied with their purchase.
                We have the knowledge and ability to handle any type of auction. We handle small local sales,
                and large multiple-day, multi-million dollar auctions. Our services are tailored to fit each client's
                needs.
            </h5>
        </div>
    </section>

    <?php
  require_once("footer.php");
  ?>

</body>

</html>