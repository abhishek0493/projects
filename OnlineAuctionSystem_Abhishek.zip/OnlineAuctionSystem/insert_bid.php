<?php
session_start();
require_once('config.php');
$bid = $_POST['bid'];
$userID = $_SESSION['user_id'];
$id = $_POST['prod_id'];

$select = "SELECT * FROM online_auction_bids WHERE prod_id='$id'";
$query = mysqli_query($conn,$select);
$res = mysqli_fetch_assoc($query);

$select2 = "SELECT * FROM online_auction_product WHERE prod_id='$id'";
$query2 = mysqli_query($conn,$select2);
$res2 = mysqli_fetch_assoc($query2);

$select3  = "SELECT * FROM online_auction_bidlog WHERE prod_id='$id'";
$query3 = mysqli_query($conn,$select3);
$res3 = mysqli_fetch_assoc($query3);



// Insert bid when no Bidding is done on the product
if($userID != $res2['u_id']) {

    if(($bid > $res2['starting_bid']) && mysqli_num_rows($query) == 0) {
        $insert = "INSERT INTO online_auction_bids (user_id,prod_id,bid_amount) VALUES('$userID','$id','$bid')";
        mysqli_query($conn,$insert);
        header("Location:bid_success.php");
        } else {
          header("Location:bid_success.php?bid_error=1");
        };       
  } else {
    header("Location:bid_success.php?bid_error=3");
      }


if($userID != $res2['u_id']){
  if($bid > $res2['starting_bid']){
    if($res3['user_id'] != $userID) {
    $insert2 = "INSERT INTO online_auction_bidlog (user_id,prod_id,amount) VALUES('$userID','$id','$bid')";
    mysqli_query($conn,$insert2);
    }
  }
}




// Update bid
if($userID != $res2['u_id']) {
  if(mysqli_num_rows($query) > 0) {
    if($bid > $res['bid_amount']) {

        $update = "UPDATE online_auction_bids SET bid_amount='$bid',user_id='$userID' WHERE prod_id='$id'";
        mysqli_query($conn,$update);

         if($res3['user_id'] == $userID){
              $update2 = "UPDATE online_auction_bidlog SET amount='$bid' WHERE user_id='$userID'";
              mysqli_query($conn,$update2);
            }

        header("Location:bid_success.php");

          } else {
            header("Location:bid_success.php?bid_error=2");
            }
// Update bid only if the user is same
           
  }

} else {
    header("LocationL:bid_success.php?bid_error=3");
}

?>