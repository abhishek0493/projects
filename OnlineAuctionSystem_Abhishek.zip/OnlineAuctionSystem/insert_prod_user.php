<?php


require_once('config.php');

$pname = $_POST['pname'];
$cat = $_POST['category'];
$descript = $_POST['descript'];
$image = $_FILES['image']['name'];

$img_array = explode(".", $image);
$ext = $img_array[count($img_array) - 1];
$new_file = Date("Ymdhis");
$new_image = $new_file . "." . $ext;

$source = $_FILES['image']['tmp_name'];
$destination = "uploads/" . $new_image;
move_uploaded_file($source, $destination);

$start_bid = $_POST['start_bid'];
$start_date = $_POST['start_date'];
$due_date = $_POST['due_date'];
$u_id = $_POST['user_id'];
$current_date = strtotime(date("d-m-Y"));
$current_date2 = strtotime(date("d-m-Y H:i:s"));
$start_date2 = strtotime($_POST['start_date']);
$due_date2 = strtotime($_POST['due_date']);

// if($start_date >= $current_date) {
//     echo "true";
// } else {
//     echo "fasle";
// }

if ($pname != "" && $cat != "Select a Category" && $start_date != "" && $due_date != "" && $image != "") {

    if (($start_date2 >= $current_date) && ($due_date2 >= $current_date2) && ($due_date2 > $start_date2)) {
        $insert  = "INSERT INTO online_auction_product (cat_id,name,description,p_image,starting_bid,start_date,due_date,u_id) 
                VALUES ('$cat','$pname','$descript','$new_image','$start_bid','$start_date','$due_date','$u_id')";
        mysqli_query($conn, $insert);
        header("Location:view_prod_final.php?p_add=1");
    } else {
        header("Location:add_prod_user.php?error=2");
    }
} else {
    header("Location:add_prod_user.php?error=1");
}