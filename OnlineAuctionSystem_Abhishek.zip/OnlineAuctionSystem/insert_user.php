<?php

require_once('config.php');

$select  = "SELECT * FROM online_auction_users";
$query = mysqli_query($conn, $select);
$res = mysqli_fetch_assoc($query);

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$contact = $_POST['contact'];
if ($name != "" && $email != "" && $password != "" && $contact != "") {
    if ($res['email'] != $email && $res['password'] != $password) {


        $insert = "INSERT INTO online_auction_users(name,email,password,contact) VALUES ('$name','$email','$password','$contact')";
        mysqli_query($conn, $insert);
        header("Location:login_user.php");
    } else {
        header("Location:register_user.php?r_error=2");
    }
} else {
    header("Location:register_user.php?r_error=1");
}
