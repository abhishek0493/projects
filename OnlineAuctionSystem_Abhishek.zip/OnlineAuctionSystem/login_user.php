<?php

require_once('header.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
</head>

<body>



    <section id="login_user">
        <div class="container p-3">
            <div class="row justify-content-center">
                <div class="col-lg-6 text-center">
                    <img src="./images/2942004.jpg" alt="" id="login_img">
                </div>
                <div class="col-lg-6">

                    <h3 class="mt-2 display-4 text-center" id="login_h3">LOGIN</h3>
                    <form action="check_user_login.php" method="post">
                        <div class="form-group">
                            <input type="email" placeholder="Enter email" class="mt-5 w-100" name="email">
                        </div>
                        <div class="form-group">
                            <input type="password" placeholder="Enter password" class="mt-2 w-100" name="password">
                        </div>
                        <div class="form-group">
                            <button type="submit" id="submit_btn">Submit</button>
                        </div>
                    </form>
                    <p class="text-muted mt-3">Not yet registered ? <span class="text-info ml-2"><a href="register_user.php">Click here to register</a></span></p>
                    <h4 class="text-danger"><?php if (isset($_GET['error_msg']) && $_GET['error_msg'] == 1) {
                                                echo "Invalid username or Password";
                                            }    ?></h4>

                    <h4 class="text-danger"><?php if (isset($_GET['error_msg']) && $_GET['error_msg'] == 2) {
                                                echo "You have not been approved yet by the admin";
                                            }    ?></h4>

                    <h4 class="text-danger"><?php if (isset($_GET['error_msg']) && $_GET['error_msg'] == 3) {
                                                echo "Not Yet Registered";
                                            }    ?></h4>

                </div>
            </div>
        </div>
    </section>
    <?php require_once('footer.php');
    ?>

</body>

</html>