<?php


require_once('header.php');

?>

 <section id="register">
      <div class="container-fluid jumbotron text-center">
        <form action="insert_user.php" method="post">
          <h1 class="my-4 display-3">Create your account</h1>
          <p class="text-muted">We'll need some details to get you started</p>

          <div class="row justify-content-center mx-auto mt-3">
            <div class="col-lg-6 mx-auto p-4 rounded">
              <div class="form-group">
                <input
                  type="text"
                  class="form-control my-3"
                  placeholder="Enter Name"
                  name="name"
                />
                <input
                  type="email"
                  placeholder="Enter Email"
                  name="email"
                  class="form-control my-3"
                />
                <input
                  type="password"
                  placeholder="Enter Password"
                  name="password"
                  class="form-control my-3"
                />
                <input
                  type="text"
                  placeholder="Enter Contact"
                  name="contact"
                  class="form-control my-3"
                />
                <input
                  type="submit"
                  value="Register"
                  class="btn btn-success btn-lg mt-4"
                />
              </div>
            </div>
          </div>

           <?php   
        if(isset($_GET["r_error"]) && $_GET["r_error"] == 1) {
          echo "<h3 class='text-danger'>All Fields are mandatory</h3>";
        } elseif(isset($_GET["r_error"]) && $_GET["r_error"] == 2){
          echo "<h3 class='text-danger'>Already registered</h3>";
        }
        ?>
          
        </form>
       
      </div>
    </section>