<?php

require_once("config.php");
require_once('header.php');
$select  = "SELECT * FROM online_auction_category";
$query = mysqli_query($conn, $select);

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Categories</title>
</head>

<body>

  <?php
  require_once('header.php');

  ?>

  <section id="category">
    <h2 class="display-4 ml-5">Categories</h2>
    <div class="container-fluid shadow-lg my-5">
      <div class="row">
        <?php
        while ($res = mysqli_fetch_assoc($query)) {

          ?>
          <div class="col p-5">
            <div class="card shadow-md">
              <div class="card-body">
                <img src="./Admin/uploads/<?php echo $res['cat_image'];   ?>" alt="" height="150" width="150" class="mx-auto d-block" />
              </div>
              <div class="card-footer">
                <a class="text-center stretched-link" href="view_prod_by_cat2.php?id=<?php echo $res['cat_id'];  ?>"> <?php echo $res['cat_name'];  ?></a>
              </div>
            </div>
          </div>

        <?php  } ?>
      </div>
    </div>
  </section>

  <?php
  require_once('footer.php');
  ?>

</body>

</html>