<?php

// header("location:view_prod_final.php");
require_once('config.php');
$select = "SELECT * FROM online_auction_product ORDER BY prod_id DESC";
$query = mysqli_query($conn, $select);

$current_date = Date("Y-m-d H:i:s");

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>View Products</title>
    <?php require_once("header.php"); ?>
</head>

<body>

    <section id="view_prod_2">
        <?php
        if (isset($_GET['p_add']) && $_GET['p_add'] == 1) {
            echo "<div class='alert alert-success text-center mx-auto'>
            <h4>Product added successfully , please wait for admin approval</h4>
            </div>";
        }
        ?>
        <div class="alert alert-success">
            <h4 class="text-center font-weight-bold">Products avaliable for bidding</h4>
        </div>


        <div class="container-fluid">

            <div class="row justify-content-center text-center mt-2">
                <?php
                while ($res = mysqli_fetch_assoc($query)) {
                    if ($res['status'] == 1 && $res['start_date'] <= $current_date) {
                        // to display bids placed on the products
                        $id = $res['prod_id'];
                        // $select2 = "SELECT * FROM online_auction_bids WHERE prod_id='$id'";
                        $select2 = "SELECT online_auction_bids.*,
                        online_auction_users.name as winner_name,online_auction_users.email as winner_email FROM online_auction_bids
                        JOIN online_auction_users ON online_auction_bids.user_id = online_auction_users.user_id WHERE prod_id='$id'";
                        $query2 = mysqli_query($conn, $select2);
                        $res2 = mysqli_fetch_assoc($query2);
                        ?>

                <div class="col mx-5 my-5" id="prod_final_main">

                    <img src="./uploads/<?php echo $res['p_image'];   ?>" alt="" height="160" width="160"
                        class="rounded">
                    <h4 class="my-3 prod-title"><?php echo $res['name'];   ?></h4>
                    <h6 class="">Base Price : <span
                            class="font-weight-bold"><?php echo $res['starting_bid'];   ?></span></h6>
                    <h6 class="">Due Date : <span class="font-weight-bold"><?php echo $res['due_date'];   ?></span></h6>
                    <?php
                                    if ($res2['bid_status'] == 1) {
                                        ?>
                    <h4 class="sold-out mt-3 w-75 mx-auto">SOLD OUT</h4>
                    <?php  } else {
                                        ?>
                    <a href="" onclick="insert_bid(<?php echo $res['prod_id']; ?>)"
                        class="btn btn-lg mt-3 w-75 btn-primary mx-auto d-block" data-toggle="modal"
                        data-target="#enter_bid_modal" id="bid-btn">Bid</a>
                    <?php      }  ?>

                    <h5 class="mt-3 font-weight-bold current-bid">Current Bid :
                        <?php if (mysqli_num_rows($query2) > 0 && $res2['bid_status'] == "0") {
                                            ?>
                        <span class="text-primary ml-1"><?php echo $res2['bid_amount']; ?></span>
                        <?php  } elseif (mysqli_num_rows($query2) > 0 && $res2['bid_status'] == "1") {
                                            ?>
                        <span class="text-danger ml-1">Bidding Closed</span>
                        <?php  } else {
                                            ?>
                        <span class="text-primary ml-1">N/A</span>

                        <?php  } ?>
                    </h5>

                    <!-- Check if the user is the highest bidder -->
                    <?php
                                    if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != "") {
                                        ?>
                    <p id="high_bid" class="text-warning d-block mt-2 text-center"><?php if ($_SESSION['user_id'] == $res2['user_id']) {
                                                                                                                echo "You are the highest bidder";
                                                                                                            } ?></p>
                    <?php  }  ?>


                    <?php
                                    $due_date = $res['due_date'];
                                    if ($current_date >= $due_date) {

                                        $update = "UPDATE online_auction_bids SET bid_status='1' WHERE prod_id='$id'";
                                        mysqli_query($conn, $update);
                                        // echo "Over";
                                        if ($res2['bid_status'] == 1) {

                                            ?>
                    <p class="text-success font-weight-bold d-block mt-1 text-center w-75 mx-auto winner">
                        <?php echo $res2['winner_email'] . " has won the bid"
                                                        ?>
                    </p>

                    <?php  }
                                    }

                                    ?>


                </div>




                <?php }
                }
                ?>

            </div>


    </section>

    <div class="modal fade" id="enter_bid_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <?php
            if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != "") {
                ?>
            <div class="modal-content">
                <div class="modal-header">

                    <p class="modal-title text-center" id="exampleModalLabel">Enter Bid</p>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form action="insert_bid.php" method="post">
                        <input type="text" name="bid" placeholder="Enter Bid Amount" class="form-control my-3">
                        <input type="hidden" name="prod_id">
                        <input type="submit" value="Submit" class="btn btn-success mx-auto d-block mt-3">
                    </form>
                </div>
            </div>
            <?php  } else {
                ?>
            <div class="modal-content">
                <div class="modal-header text-center">

                    <p class="modal-title" id="exampleModalLabel">Sorry you can not Bid yet</p>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body p-5">
                    <h3 class="text-center text-muted">Please <a href="login_user.php">Login</a> to place a bid</h3>
                    <h3 class="text-center text-muted mt-3">Not yet registered ? <a href="register_user.php">Click
                            Here</a> to register</h3>
                </div>
            </div>
            <?php  }  ?>

        </div>
    </div>

    <script>
    function insert_bid(id) {
        $.ajax({
            url: 'get_prod_id.php',
            data: 'id=' + id,
            type: 'post',
            dataType: 'json',
            success: function(data) {
                $('input[name="prod_id"]').val(data.prod_id);
            }
        });
    };
    </script>


</body>

</html>