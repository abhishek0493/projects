<?php

require_once('config.php');
require_once('header.php');
$cat_id = $_GET['id'];
$select = "SELECT * FROM online_auction_product WHERE cat_id='$cat_id'";
$query = mysqli_query($conn,$select);

$info = getdate();
$date = $info['mday'];
$month = $info['mon'];
$year = $info['year'];
$hours = $info['hours'];
$min = $info['minutes'];
$sec = $info['seconds'];
$current_date = "$year-$month-$date $hours:$min:$sec";

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>View Products</title>
</head>
<body>

        <section id="view_prod">
        <?php
        if(mysqli_num_rows($query)){
        ?>
            <h2 class="text-center text-muted my-4">Products avaliable for bidding</h2>
            <div class="container-fluid shadow-lg p-5">
                <?php
                // Display all approved products
                while($res = mysqli_fetch_assoc($query)) {
                    if($res['status'] == 1) {
                        // to display bids placed on the products
                        $id = $res['prod_id'];
                        // $select2 = "SELECT * FROM online_auction_bids WHERE prod_id='$id'";
                        $select2 = "SELECT online_auction_bids.*,
                        online_auction_users.name as winner_name,online_auction_users.email as winner_email FROM online_auction_bids
                        JOIN online_auction_users ON online_auction_bids.user_id = online_auction_users.user_id WHERE prod_id='$id'";
                        $query2 = mysqli_query($conn,$select2);
                        $res2 = mysqli_fetch_assoc($query2);

                ?>
                <div class="card mb-4 mx-auto w-75">
                    <div class="row no-gutters p-3 shadow-lg justify-content-center">
                        <div class="col-lg-2 text-center p-3">
                            <img src="uploads/<?php echo $res['p_image']; ?>" height="200" width="200" class="mx-auto d-block">
                        </div>
                        <div class="col-lg-8">
                            <div class="card-body text-center">
                                <h2 class="text-secondary" style="font-weight:500"><?php echo $res['name'];?></h2>
                                <p class="text-info my-3 mx-auto w-75"><?php echo $res['description'];  ?></p>
                                <a href=""  onclick="insert_bid(<?php echo $res['prod_id'];?>)" 
                                class="btn btn-success text-white btn-lg mx-auto mt-3 w-25 <?php if($res2['bid_status'] == 1){echo "disabled";}?>" 
                                data-toggle="modal" data-target="#enter_bid_modal" id="bid"
                                >Bid</a>

                                    <!-- Check if the user is the highest bidder -->
                                    <?php  if(isset($_SESSION['user_id']) && $_SESSION['user_id'] != ""){ 
                                        
                                    ?>
                                    <h5 id="high_bid" class="text-warning d-block font-weight-bold mt-5"><?php if($_SESSION['user_id'] == $res2['user_id']){echo "You are the highest bidder";}?></h5> 
                                    <?php  }  ?>

                                    <!-- Check Winner -->

                                     <?php 
                                        $due_date = $res['due_date'];
                                        if($due_date <= $current_date) {
                                            $update = "UPDATE online_auction_bids SET bid_status='1' WHERE prod_id='$id'";
                                            mysqli_query($conn,$update);
                                            // echo "Over";
                                        ?>
                                         <h5 class="text-primary d-block font-weight-bold mt-5">
                                        <?php echo $res2['winner_name']." has won the bid";
                                              echo "<br>";
                                              echo $res2['winner_email'];
                                        ?>
                                        </h5>

                                        <?php  }  
                                        
                                        ?>

		
                                <div class="countdown"></div>
 
                               
                            



                            </div>
                        </div>
                        <div class="col-lg-2 rounded">
                            <div class="card-body">
                                <h5 class="text-dark mb-4 font-weight-bold">Base Price<span class="text-success d-block"><?php echo $res['starting_bid'];   ?></span></h5>
                                <h5 class="text-dark my-4 font-weight-bold">Start date<span class="text-danger d-block"><?php echo $res['start_date'];   ?></span></h5>
                                <h5 class="text-dark my-4 font-weight-bold">Due date<span class="text-danger d-block"><?php echo $res['due_date'];   ?></span></h5>
                                <h5 class="text-dark my-4 font-weight-bold">Current Bid
                                <?php  if(mysqli_num_rows($query2) > 0 && $res2['bid_status'] == "0") {
                                ?>
                                <span class="text-primary d-block"><?php echo $res2['bid_amount']; ?></span>
                                <?php  } elseif(mysqli_num_rows($query2) > 0 && $res2['bid_status'] == "1") {
                                    ?>
                                <span class="text-primary d-block">Bidding Closed</span>
                                <?php  } else {
                                ?>
                                <span class="text-primary d-block">N/A</span>

                                <?php  }  ?>
                                </h5>

                            </div>
                        </div>
                    </div>
                </div>

                <?php
                } 
            }
            ?>

            </div>

        <?php  } else{echo "<h1 class='display-3 text-center mt-5'>No Products available currently</h1>";
        echo "<a href='view_cat.php' class='btn btn-success mt-5 d-block mx-auto w-25'>Go Back</a>";
        }
          ?>
     
            </section>

            <div class="modal fade" id="enter_bid_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                        <?php
                            if(isset($_SESSION['user_id']) && $_SESSION['user_id'] != "") {
                        ?>
                        <div class="modal-content">
                            <div class="modal-header">
                               
                                <h5 class="modal-title text-center" id="exampleModalLabel">Enter Bid</h5>
                               
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">

                                <form action="insert_bid.php" method="post">
                                    <input type="text" name="bid" placeholder="Enter Bid Amount" class="form-control my-3" >
                                    <input type="hidden" name="prod_id">
                                    <input type="submit" value="Submit" class="btn btn-success mx-auto d-block mt-3">
                                </form>
                            </div>
                        </div>
                            <?php  } else {
                            ?>
                        <div class="modal-content">
                             <div class="modal-header text-center">
                               
                                <h5 class="modal-title" id="exampleModalLabel">Sorry you cant Bid yet</h5>
                               
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body p-5">
                                <h5 class="text-center text-danger">Please <a href="login_user.php">Login</a> to place a bid</h5>
                                <h6 class="text-center text-success mt-3">Not yet registered ? <a href="register_user.php">Click Here</a> to register</h6>
                            </div>
                        </div>
                            <?php  }  ?>

                    </div>
                </div>

            <script>
               function insert_bid(id){
                   $.ajax({
                       url:'get_prod_id.php',
                       data:'id='+id,
                       type:'post',
                       dataType:'json',
                       success:function(data){
                            $('input[name="prod_id"]').val(data.prod_id);
                       }
                   });
               };

            </script>

           

                            

      
</body>
</html>


 

 