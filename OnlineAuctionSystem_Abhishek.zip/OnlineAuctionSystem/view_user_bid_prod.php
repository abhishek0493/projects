<?php
require_once("config.php");
require_once("header.php");
$userId = $_SESSION['user_id'];

$select = "SELECT * FROM online_auction_bidlog WHERE user_id='$userId' ORDER BY id DESC";
$query = mysqli_query($conn, $select);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>My Bids</title>
</head>

<body>

    <section id="user_bid">
        <div class="container-fluid jumbotron">
            <h2 class="text-center display-4 font-weight-bold">Your Bids</h2>

            <?php
            if (mysqli_num_rows($query) > 0) {
                ?>

            <div class="row justify-content-center mt-5">
                <?php
                        while ($res = mysqli_fetch_assoc($query)) {
                            $prod = $res['prod_id'];
                            $select2 = "SELECT * FROM online_auction_product WHERE prod_id='$prod'";
                            $query2 = mysqli_query($conn, $select2);
                            $res2 = mysqli_fetch_assoc($query2);

                            $select3 = "SELECT * FROM online_auction_bids WHERE prod_id='$prod'";
                            $query3 = mysqli_query($conn, $select3);
                            $res3 = mysqli_fetch_assoc($query3);

                            ?>
                <div class="col text-center mx-3 p-5 my-3 <?php if ($res3['user_id'] == $userId) {
                                                                                echo "border";
                                                                            } ?>">
                    <img src="./uploads/<?php echo $res2['p_image']; ?>" alt="" height="150" width="150"
                        class="rounded-circle">
                    <h3 class="my-3 text-uppercase font-weight-bold"><?php echo $res2['name']; ?></h3>
                    <h5 class="text-muted">Last Bid : <?php echo $res['amount']; ?></h5>
                    <h5 class="text-muted"> <?php if ($res3['bid_status'] == 1) {
                                                                echo "Closing Bid :";
                                                            } else {
                                                                echo "Current Bid :";
                                                            }  ?> <?php echo $res3['bid_amount']; ?></h5>
                    <?php
                                    if ($res3['bid_status'] == 0) {
                                        ?>
                    <h5 class="text-success font-weight-bold mt-3">Bid Open</h5>
                    <?php   } else if ($res3['user_id'] == $userId && $res3['bid_status'] == 1) {
                                        ?>
                    <h5 class="text-danger font-weight-bold mt-3">You won the product</h5>
                    <?php  } else {
                                        echo "<h5 class='text-danger font-weight-bold mt-3'>Sold Out</h5>";
                                    }  ?>
                </div>

                <?php  } ?>
            </div>
        </div>
        <?php } else {
        ?>
        <h3 class="display-4 text-center mt-5 text-danger">You have not Placed any bids Yet</h3>
        <a href="view_prod_final.php" class="text-info mt-4 d-block text-center">View all products</a>

        <?php  }  ?>

    </section>

    <?php require_once('footer.php');  ?>


</body>

</html>